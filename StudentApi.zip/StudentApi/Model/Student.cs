﻿namespace StudentApi.Model
{
    public class Student
    {
        public int Id{ get; set; }
        public string Name { get; set; }
        public int Age {  get; set; }
        public double Grade { get; set; }

        public string Email { get; set; }
        public string PasswordHash { get; set; }
        public string Role { get;set; }


        public string RefreshTokenHash { get; set; }
        public DateTime? RefreshTokenExpiresAt { get; set; }
        public DateTime? RefreshTokenRevokedAt { get; set; }
    }
}
