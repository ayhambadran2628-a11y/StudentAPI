﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using StudentApi.Model;
using StudentApi.DataSimlation;
using Microsoft.AspNetCore.Authorization;
using System.Security.Claims;

namespace StudentApi.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/Student")]
    
    public class StudentController : ControllerBase
    {


        [Authorize(Roles = "Admin")]
        [HttpGet("All",Name = "All")]
        public ActionResult<IEnumerable<Student>> GetAllStudent()
        {
            return Ok(StudentDataSimulaion.StudentList);
        }
        
        
        
        
        [AllowAnonymous]
        [HttpGet("Pass" , Name ="Pass")]
        public ActionResult<IEnumerable<Student>> GetAllStudentsPass()
        {
            List<Student> students = StudentDataSimulaion.StudentList;

            return Ok(students.Where(i => i.Grade > 60));

        }
       
        
        
        [AllowAnonymous]
        [HttpGet("Avg", Name = "Avg")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public ActionResult<double> GetAvgStudents()
        {
            List<Student> students = StudentDataSimulaion.StudentList;

            if (students.Count == 0)
                return NotFound("No Student Found");

            return Ok(students.Average(i => i.Grade));

        }



        [HttpGet("{ID}", Name = "GetStudentByID")]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<ActionResult<Student>> GetStudentByID(int ID, [FromServices]IAuthorizationService authorizationService)
        {
            if (ID < 1)
                return BadRequest("Bad Request For: " + ID);
            var student = StudentDataSimulaion.StudentList.FirstOrDefault(s => s.Id == ID);

            if (student == null)
                return NotFound("Not Found Student For: " + ID);


            var authResult = await authorizationService.AuthorizeAsync(User,ID,"StudentOwnerOrAdmin");
           

            if (!authResult.Succeeded)
                return Forbid(); // 403

            return Ok(student);


        }


        [Authorize(Roles = "Admin")]
        [HttpPost(Name = "AddNewStudent")]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status201Created)]
        public ActionResult<Student> AddNewStudent(Student newStudent)
        {
            if (newStudent == null)
                return BadRequest("Bad Request");

            newStudent.Id = StudentDataSimulaion.StudentList.Count != 0 ? StudentDataSimulaion.StudentList.Max(s => s.Id) + 1 : 1;
            StudentDataSimulaion.StudentList.Add(newStudent);

            return CreatedAtRoute("GetStudentByID" ,new {id = newStudent.Id},newStudent);

        }



        [Authorize(Roles = "Admin")]
        [HttpDelete("{ID}", Name = "DeleteStudent")]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public ActionResult DeleteStudent(int ID)
        {
            if (ID < 1)
                return BadRequest("Bad Request");

            var s = StudentDataSimulaion.StudentList.FirstOrDefault(i => i.Id == ID);
            if (s == null)
                return NotFound("not found");

            StudentDataSimulaion.StudentList.Remove(s);
            return Ok("Student Deleted");
        }


        [Authorize(Roles = "Admin")]
        [HttpPut("{id}", Name = "UpdateStudent")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public ActionResult<Student> UpdateStudent(int id, Student updatedStudent)
        {
            if (id < 1 || updatedStudent == null || string.IsNullOrEmpty(updatedStudent.Name) || updatedStudent.Age < 0 || updatedStudent.Grade < 0)
            {
                return BadRequest("Invalid student data.");
            }

            var student = StudentDataSimulaion.StudentList.FirstOrDefault(s => s.Id == id);
            if (student == null)
            {
                return NotFound($"Student with ID {id} not found.");
            }

            student.Name = updatedStudent.Name;
            student.Age = updatedStudent.Age;
            student.Grade = updatedStudent.Grade;

            return Ok(student);
        }
    }


}

